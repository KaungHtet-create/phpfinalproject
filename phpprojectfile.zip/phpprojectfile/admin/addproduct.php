<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<?php
error_reporting(1);
include("connection.php");
$img=$_FILES['img']['name'];
$prono=$_POST['t1'];
$price=$_POST['t2'];
if($_POST['sub'])
{$qry="INSERT INTO product(img,pro_type,price)VALUES('$img','$prono','$price')";
$result=mysql_query($qry) or die ("save items query fail.");
if($result)			
	   {mkdir("images/$i");
			move_uploaded_file($_FILES['img']['tmp_name'],"images/$i".$_FILES['img']['name']);	
  // move_uploaded_file($_FILES['file']['tmp_name'],"itempics/$itemno.jpg");
		
	    $err="<font size='+2'>item inserted successfully</font>";
	
		}
	else
	 {
	   echo "item is not inserted";
	   }
	}  
	mysql_close($con);
?>
            
        
    

<!DOCTYPE html>
<html>
    <head>
        <title>Online food Order system</title>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="style.css">
        <!--slide-->
        <link rel="stylesheet" href="code/bootstrap.min.css">
        <script src="code/jquery.min.js"></script>
        <script src="code/popper.min.js"></script>
        <script src="code/bootstrap.min.js"></script>
        
        <!--slide-->
    </head>
    <body>
        <div class="header">
           <div class="logo">
                <img src="img/logo.png" alt="" class="logoimg">
           </div>
           <div class="menu">
           <ul>
                    <li class="item"><a href="index.php">Home</a></li>
                    <li class="item"><a href="addproduct.php">Addproduct</a></li>
                    <li class="item"><a href="viewproduct.php">Viewproduct</a></li>
                    <li class="item"><a href="vieworder.php">ViewOrder</a></li>
                    <li class="item"><a href="viewfeeback.php">Viewfeeback</a></li>
                    <li class="item"><a href="viewregister.php">Viewregister</a></li>
                    <li class="item"><a href="logout.php">Logout</a></li>
                </ul>

           </div>
        </div>

     
     <table align="center" >
     <form method="post" enctype="multipart/form-data">
    <tr>
        <td>Images  :</td>
        <td><input type="file" name="img"/></td>
    </tr>
    <tr>
        <td>Product type  :</td>
        <td><input type="text" name="t1"/></td>
    </tr>
    <tr>
        <td>Price  :</td>
        <td><input type="text" name="t2"/></td>
    </tr>
    <tr>
        <td></td>
        <td><input type="submit" name="sub" value="insert">
    </tr>
    </form>

    </table>

    <?php
        }
     ?>
        <div class="footer">
          <div class="footermenu">
          <ul>
              <li class="item fi"><a href="home.php">Home</a></li>
              <li class="item fi"><a href="addproduct.php">Addproduct</a></li>
              <li class="item fi"><a href="viewproduct.php">Viewproduct</a></li>
              <li class="item fi"><a href="vieworder.php">Vieworder</a></li>
              <li class="item fi"><a href="viewfeeback.php">Viewfeeback</a></li>
              <li class="item fi"><a href="viewregister.php">Viewregisters</a></li>
          </ul>
     </div>
          <center><p>@company;Jole</p></center>
        </div>
    </body>
</html>
