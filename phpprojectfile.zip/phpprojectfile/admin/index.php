<!DOCTYPE html>
<html>
    <head>
        <title>Online food Order system</title>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="style.css">
        <!--slide-->
        <link rel="stylesheet" href="code/bootstrap.min.css">
        <script src="code/jquery.min.js"></script>
        <script src="code/popper.min.js"></script>
        <script src="code/bootstrap.min.js"></script>
        
        <!--slide-->
    </head>
    <body>
        <div class="header">
           <div class="logo">
                <img src="img/logo.png" alt="" class="logoimg">
           </div>
           <div class="menu">
                <ul>
                    <li class="item"><a href="home.php">Home</a></li>
                    <li class="item"><a href="addproduct.php">Addproduct</a></li>
                    <li class="item"><a href="viewproduct.php">Viewproduct</a></li>
                    <li class="item"><a href="vieworder.php">ViewOrder</a></li>
                    <li class="item"><a href="viewfeeback.php">Viewfeeback</a></li>
                    <li class="item"><a href="viewregister.php">Viewregister</a></li>
                    <li class="item"><a href="logout.php">Logout</a></li>
                </ul>

           </div>
        </div>
      
          <div class="login">
            <h1>Admin Login</h1>
                <div class="loginform">
                  <div class="adminlogin">
                <form method="post">
                    <label class="loginitem" >Name :</label>
                    <input type="text" class="loginitem" name="id">
                   
                    <label class="loginitem">Password :</label>
                    <input type="password" class="loginitem" name="pwd">
                    <input type="submit" class="loginbt" name="sub" value="LOGIN">
                </form>
                </div>
                </div>
            </div>
    
        <div class="footer">
          <div class="footermenu">
          <ul>
              <li class="item fi"><a href="home.php">Home</a></li>
              <li class="item fi"><a href="addproduct.php">Addproduct</a></li>
              <li class="item fi"><a href="viewproduct.php">Viewproduct</a></li>
              <li class="item fi"><a href="vieworder.php">Vieworder</a></li>
              <li class="item fi"><a href="viewfeeback.php">Viewfeeback</a></li>
              <li class="item fi"><a href="viewregister.php">Viewregisters</a></li>
          </ul>
     </div>
          <center><p>@company;Jole</p></center>
        </div>
    </body>
</html>
<?php
session_start();
error_reporting(1);
include("connection.php");
if(isset($_POST['sub']))
{
    if($_POST['id']=="" || $_POST['pwd']=="")
    {
        $err="Please fill your name or password";
    }
    else{
        $d=mysql_query("select * from user where Name='{$_POST['id']}'");
        $row=mysql_fetch_object($d);
        $fid=$row->Name;
        $fpwd=$row->Password;
        if($fid==$_POST['id'] && $fpwd==$_POST['pwd'])
        {$_SESSION['sid']=$_POST['id'];
            header("location:home.php");
        }
    }
}
?>