<!DOCTYPE html>
<html>
    <head>
        <title>Online food Order system</title>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="style.css">
        <!--slide-->
        <link rel="stylesheet" href="code/bootstrap.min.css">
        <script src="code/jquery.min.js"></script>
        <script src="code/popper.min.js"></script>
        <script src="code/bootstrap.min.js"></script>
        
        <!--slide-->
    </head>
    <body>
        <div class="header">
           <div class="logo">
                <img src="img/logo.png" alt="" class="logoimg">
           </div>
           <div class="menu">
                <ul>
                    <li class="item"><a href="index.php">Home</a></li>
                    <li class="item"><a href="addproduct.php">Addproduct</a></li>
                    <li class="item"><a href="viewproduct.php">Viewproduct</a></li>
                    <li class="item"><a href="vieworder.php">ViewOrder</a></li>
                    <li class="item"><a href="viewfeeback.php">Viewfeeback</a></li>
                    <li class="item"><a href="viewregister.php">Viewregister</a></li>
                    <li class="item"><a href="logout.php">Logout</a></li>
                </ul>

           </div>
        </div>
      <div class="home">
      <h2>Welcome Admin Panel</h2>
      <img src="img/ab.gif" class="adminimg">
      </div>
        <div class="footer">
          <div class="footermenu">
          <ul>
              <li class="item fi"><a href="home.php">Home</a></li>
              <li class="item fi"><a href="addproduct.php">Addproduct</a></li>
              <li class="item fi"><a href="viewproduct.php">Viewproduct</a></li>
              <li class="item fi"><a href="vieworder.php">Vieworder</a></li>
              <li class="item fi"><a href="viewfeeback.php">Viewfeeback</a></li>
              <li class="item fi"><a href="viewregister.php">Viewregisters</a></li>
          </ul>
     </div>
          <center><p>@company;Jole</p></center>
        </div>
    </body>
</html>
