<?php
session_start();
if($_SESSION['sid']=='')
{
    header("location:index.php");
}
else{
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Online food Order system</title>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="style.css">
        <!--slide-->
        <link rel="stylesheet" href="code/bootstrap.min.css">
        <script src="code/jquery.min.js"></script>
        <script src="code/popper.min.js"></script>
        <script src="code/bootstrap.min.js"></script>
        
        <!--slide-->
    </head>
    <body>
        <div class="header">
           <div class="logo">
                <img src="img/logo.png" alt="" class="logoimg">
           </div>
           <div class="menu">
                <ul>
                    <li class="item"><a href="index.php">Home</a></li>
                    <li class="item"><a href="addproduct.php">Addproduct</a></li>
                    <li class="item"><a href="viewproduct.php">Viewproduct</a></li>
                    <li class="item"><a href="vieworder.php">ViewOrder</a></li>
                    <li class="item"><a href="viewfeeback.php">Viewfeeback</a></li>
                    <li class="item"><a href="viewregister.php">Viewregister</a></li>
                    <li class="item"><a href="logout.php">Logout</a></li>
                </ul>

           </div>
        </div>
      <div class="viewproduct">
      <h3 align="center">Viewproduct</h3><br>
     <?php
        error_reporting(1);
        include("connection.php");
        $sel=mysql_query("select * from product");
        echo "<form method='post'><table align='center' style='width:600p; border:1px solid black; '><tr><th width='100px' align='center'>Image</th><th width='100px' align='center'>Product Name</th><th width='100px' align='center'>Price</th></tr>";
        $n=0;
        while($arr=mysql_fetch_array($sel))
        {
            $i=$arr['img'];
            if($n%1==0)
            {
                echo "<tr><tr>";
            }
            echo "<td width='250px' height='250px' align='center'><img src='images/$i' width='200px' height='200px'></td>
            <b><td width='100px' align='center'>".$arr['pro_type'].
            "</td><td width='100px' align='center'>".$arr['price'].
            "</td>";
            $n++;

        }
        echo "</tr></table></form>";



     ?>
      </div>
      <?php
}
      ?>
        <div class="footer">
          <div class="footermenu">
          <ul>
              <li class="item fi"><a href="home.php">Home</a></li>
              <li class="item fi"><a href="addproduct.php">Addproduct</a></li>
              <li class="item fi"><a href="viewproduct.php">Viewproduct</a></li>
              <li class="item fi"><a href="vieworder.php">Vieworder</a></li>
              <li class="item fi"><a href="viewfeeback.php">Viewfeeback</a></li>
              <li class="item fi"><a href="viewregister.php">Viewregisters</a></li>
          </ul>
     </div>
          <center><p>@company;Jole</p></center>
        </div>
    </body>
</html>
