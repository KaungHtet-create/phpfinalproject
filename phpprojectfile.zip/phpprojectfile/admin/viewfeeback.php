<?php
session_start();
if($_SESSION['sid']=='')
{
    header("location:index.php");
}
else{
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Online food Order system</title>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="style.css">
        <!--slide-->
        <link rel="stylesheet" href="code/bootstrap.min.css">
        <script src="code/jquery.min.js"></script>
        <script src="code/popper.min.js"></script>
        <script src="code/bootstrap.min.js"></script>
        
        <!--slide-->
    </head>
    <body>
        <div class="header">
           <div class="logo">
                <img src="img/logo.png" alt="" class="logoimg">
           </div>
           <div class="menu">
                <ul>
                    <li class="item"><a href="index.php">Home</a></li>
                    <li class="item"><a href="addproduct.php">Addproduct</a></li>
                    <li class="item"><a href="viewproduct.php">Viewproduct</a></li>
                    <li class="item"><a href="vieworder.php">ViewOrder</a></li>
                    <li class="item"><a href="viewfeeback.php">Viewfeeback</a></li>
                    <li class="item"><a href="viewregister.php">Viewregister</a></li>
                    <li class="item"><a href="logout.php">Logout</a></li>
                </ul>

           </div>
        </div>
      <div id="viewregister">
        <h3 align="center">Viewfeeback </h3><br>
     <?php
    error_reporting(1);
    include("connection.php");
    $value=mysql_query("select * from contact");
    while($arr=mysql_fetch_array($value))
    {
        $name=$arr['Name'];
        $email=$arr['Email'];
        $mobile=$arr['Mobile'];
        $feeback=$arr['Feeback'];
    
    }
     ?>
     <table style="width:900px; text-align:center; border-collapse:collapse;" align="center" border="1px solid black">
    <tr>
        <td width="150px" height="50px">Name</td>
        <td width="150px" height="50px">Email</td>
        <td width="150px" height="50px">Mobile</td>
        <td width="150px" height="50px">Feeback</td>
    </tr>
    <tr>

    <td width="150px" height="50px"><?php echo $name;?></td>
    <td width="150px" height="50px"><?php echo $email;?></td>
    <td width="150px" height="50px"><?php echo $mobile;?></td>
    <td width="150px" height="50px"><?php echo $feeback;?></td>

    </tr>

     </table>
<?php
}
?>

      </div>
        <div class="footer">
          <div class="footermenu">
          <ul>
              <li class="item fi"><a href="home.php">Home</a></li>
              <li class="item fi"><a href="addproduct.php">Addproduct</a></li>
              <li class="item fi"><a href="viewproduct.php">Viewproduct</a></li>
              <li class="item fi"><a href="vieworder.php">Vieworder</a></li>
              <li class="item fi"><a href="viewfeeback.php">Viewfeeback</a></li>
              <li class="item fi"><a href="viewregister.php">Viewregisters</a></li>
          </ul>
     </div>
          <center><p>@company;Jole</p></center>
        </div>
    </body>
</html>
